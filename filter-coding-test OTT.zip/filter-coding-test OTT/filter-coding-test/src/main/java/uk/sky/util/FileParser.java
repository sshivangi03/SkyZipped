package uk.sky.util;
import uk.sky.data.LogEntry;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.LinkedList;
import java.util.List;

public class FileParser {

	private static final int VALID_COLUMN_LENGTH = 3;
	
	public static List<LogEntry> readData(Reader source) {
		List<LogEntry> list = new LinkedList<>();
		BufferedReader br = new BufferedReader(source);
		
		String line = "";
		int lineNumber = 0;
		try {
			while((line = br.readLine()) != null) {
				lineNumber ++;				
				if(lineNumber == 1) {
                    continue;
                }
				
				String[] columns = line.split(",");
				if(isValidEntry(columns)) {
					list.add(new LogEntry(Long.parseLong(columns[0]), columns[1], Long.parseLong(columns[2])));
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}	
		return list;		
	}
	
	private static boolean isValidEntry(String[] columns) {
		return columns.length == VALID_COLUMN_LENGTH;
	}

}
