package uk.sky.data;

public class LogEntry {
	
	
	private long requestTimestamp;
	private String countryCode;
	private long responseTime;
	
	public LogEntry(long requestTimestamp, String countryCode, long responseTime) {
		this.requestTimestamp = requestTimestamp;
		this.responseTime = responseTime;
		this.countryCode = countryCode;
	}

	public long getRequestTimestamp() {
		return requestTimestamp;
	}

	public void setRequestTimestamp(long requestTimestamp) {
		this.requestTimestamp = requestTimestamp;
	}
	
	public long getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(long responseTime) {
		this.responseTime = responseTime;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
}
